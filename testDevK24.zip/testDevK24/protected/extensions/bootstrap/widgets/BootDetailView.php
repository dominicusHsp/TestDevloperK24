<?php
/**
 * BootDetailView class file.
 * @author Christoffer Niska <ChristofferNiska@gmail.com>
 * @copyright Copyright &copy; Christoffer Niska 2011-
 * @license http://www.opensource.org/licenses/bsd-license.php New BSD License
 */

Yii::import('zii.widgets.CDetailView');
class BootDetailView extends CDetailView
{
	/**
	 * @property array the HTML options used for {@link tagName}
	 */
	public $htmlOptions=array('class'=>'detail-view');

	/**
	 * @property string the URL of the CSS file used by this detail view.
	 * Defaults to false, meaning that no CSS will be included.
	 */
	public $cssFile=false;
}
