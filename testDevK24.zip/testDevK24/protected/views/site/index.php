<?php
/* @var $this SiteController */

$this->pageTitle=Yii::app()->name;
?>
	<div style="text-align: center">
		<?php echo CHtml::image("images/logo-k-24.jpg","image",array("width"=>500)); ?>	
	</div>
<h1>Welcome to Website for <i><?php echo CHtml::encode(Yii::app()->name); ?></i></h1>

<p>Website ini dibuat menggunakan Yii Framework dengan menggunakan Theme yang di download pada <a href="https://yii.themefactory.net/theme/112/shadow-dancer#.WD3sthLi201">yii.themefactory.net</a></p>

